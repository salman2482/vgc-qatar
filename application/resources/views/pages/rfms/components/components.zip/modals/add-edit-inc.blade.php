<div class="row" id="js-rfms-modal-add-edit" data-section="{{ $page['section'] }}">
    <div class="col-lg-12">
        <!--department<>-->
        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('lang.rfm_department')) }}*</label>
            <div class="col-sm-12 col-lg-9">
                    <select class="select2-basic form-control form-control-sm" name="rfm_department" id="rfm_department"
                        data-allow-clear="false" >
                        <option value="soft service" >Soft Service</option>
                        <option value="hard service" >Hard service</option>
                        <option value="office supply" >Office Supply</option>
                        <option value="transport" >Transport</option>
                    </select>
                {{-- <input type="text" class="form-control form-control-sm" id="rfm_title" name="rfm_title"
                    placeholder="" value="{{ $rfm-> ?? '' }}"> --}}
            </div>
        </div>

        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('Select Inline Manager*')) }}</label>
            <div class="col-sm-12 col-lg-9">
                <!--select2 basic search-->
                <select name="rfm_clientid" id="rfm_clientid"
                    class="clients_and_projects_toggle form-control form-control-sm js-select2-basic-search-modal"
                    data-ajax--url="{{ url('/') }}/feed/company_managers">
                    @if(isset($rfm->inline_manager_id) && $rfm->inline_manager_id != '')
                    <option value="{{ $rfm->inline_manager_id ?? '' }}">{{ $rfm->first_name ?? '' }}
                    </option>
                    @endif
                </select>
            </div>
        </div>
        <!--subject<>-->
        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('lang.rfm_subject')) }}*</label>
            <div class="col-sm-12 col-lg-9">
                <textarea name="rfm_subject" id="rfm_subject" class="form-control form-control-sm" required cols="30" rows="10" >{{ $rfm->subject ?? ''}}</textarea>
            </div>
        </div>
        <!--/#subject-->

        <!--remarks<>-->
        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('Remarks')) }}*</label>
                <div class="col-sm-12 col-lg-9">
                    <input type="text" required name="rfm_remarks" id="rfm_remarks" class="form-control form-control-sm" value="{{ $rfm->remarks ?? ''}}" >
                </div>
        </div>
        <!--/#remarks-->

        <!--site<>-->
        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('lang.rfm_site')) }}*</label>
            <div class="col-sm-12 col-lg-9">
                <input type="text" required name="rfm_site" id="rfm_site" class="form-control form-control-sm" value="{{ $rfm->site ?? ''}}">
            </div>
        </div>
        <!--/#site-->
        <!--material<>-->
            {{-- <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('lang.rfm_material')) }}*</label>
            <table id="tbl" class="mb-2">
            <tr id="product0">
                <td>
                  <select class="form-control w-50" name="material_id[]">
                   @foreach ($materials as $material)
                       <option value="{{ $material->id }}">{{ $material->title }}</option>
                   @endforeach
                  </select>
                  <input type="number" name="qty[]" class="form-control w-25 d-inline"  placeholder="quantity">
                </td>
            </tr>
            <tr id="product1">
                
            </tr>
        </table>
        <input type="hidden" id="materials" name="materials" value="0">
        <button type="button" id="btnAdd"  class="btn btn-sm btn-dark">
            Add
        </button>                     --}}
                    

        <!--/#material-->

        <!--quantity<>-->
        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('lang.rfm_quantity')) }}*</label>
            <div class="col-sm-12 col-lg-9">
                <input type="number" required name="rfm_quantity" id="rfm_quantity" class="form-control form-control-sm" value="{{ $rfm->quantity ?? ''}}" >
            </div>
        </div>
        <!--/#quantity-->

        <!--available stock<>-->
        <div class="form-group row">
            <label
                class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('lang.rfm_stock')) }}*</label>
            <div class="col-sm-12 col-lg-9">
                <input type="number" name="rfm_available_stock" id="rfm_available_stock" class="form-control form-control-sm" value="{{$rfm->available_stock ?? ''}}" >
            </div>
        </div>
        <!--/#available stock-->
        <!--due date <>-->
        <div class="form-group row">
            <label class="col-sm-12 col-lg-3 text-left control-label col-form-label required">Due Date</label>
            <div class="col-sm-12 col-lg-9">
                <input type="text" class="form-control form-control-sm pickadate" name="rfm_due_date" autocomplete="off" value="{{ runtimeDatepickerDate($rfm->due_date ?? '') }}">
                <input class="mysql-date" type="hidden" name="rfm_due_date" id="rfm_due_date" value="{{ $rfm->due_date ?? ''}}">
            </div>
        </div>
        <!--/# due date-->
        <div>
            <label
            class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('Rfm Copy')) }}*</label>
            <!--fileupload-->
            <div class="form-group row">
                <div class="col-sm-12">
                    <div class="dropzone dz-clickable" id="rfm_image">
                        <div class="dz-default dz-message">
                            <i class="icon-Upload-toCloud"></i>
                            <span>{{ cleanLang(__('lang.drag_drop_file')) }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <!--fileupload-->
            <!--existing files-->
            @if(isset($page['section']) && $page['section'] == 'edit')
                @if (isset($attachments))
                    <table class="table table-bordered">
                        <tbody>
                            @foreach($attachments as $attachment)
                                @if ($attachment->attachment_unique_input === 'rfm_image')
                                <tr id="rfm_attachment_{{ $attachment->attachment_id ?? '' }}">
                                    <td>{{ $attachment->attachment_filename ?? '' }} </td>
                                    <td class="w-px-40"> <button type="button"
                                            class="btn btn-danger btn-circle btn-sm confirm-action-danger"
                                            data-confirm-title="{{ cleanLang(__('lang.delete_item')) }}"
                                            data-confirm-text="{{ cleanLang(__('lang.are_you_sure')) }}" active"
                                            data-ajax-type="DELETE"
                                            data-url="{{ url('/rfms/attachments/'.$attachment->attachment_uniqiueid ?? '') }}">
                                            <i class="sl-icon-trash"></i>
                                        </button></td>
                                </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                @endif
            @endif
        </div>
     

        {{-- rfm video --}}
        <div>
            <label
            class="col-sm-12 col-lg-3 text-left control-label col-form-label required">{{ cleanLang(__('Rfm Video')) }}*</label>
            <!--fileupload-->
            <div class="form-group row">
                <div class="col-sm-12">
                    <div class="dropzone dz-clickable" id="rfm_video">
                        <div class="dz-default dz-message">
                            <i class="icon-Upload-toCloud"></i>
                            <span>{{ cleanLang(__('lang.drag_drop_file')) }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <!--fileupload-->
            <!--existing files-->
            @if(isset($page['section']) && $page['section'] == 'edit')
                @if (isset($attachments))
                    <table class="table table-bordered">
                        <tbody>
                            @foreach($attachments as $attachment)
                                @if ($attachment->attachment_unique_input === 'rfm_video')
                                <tr id="rfm_attachment_{{ $attachment->attachment_id ?? '' }}">
                                    <td>{{ $attachment->attachment_filename ?? '' }} </td>
                                    <td class="w-px-40"> <button type="button"
                                            class="btn btn-danger btn-circle btn-sm confirm-action-danger"
                                            data-confirm-title="{{ cleanLang(__('lang.delete_item')) }}"
                                            data-confirm-text="{{ cleanLang(__('lang.are_you_sure')) }}" active"
                                            data-ajax-type="DELETE"
                                            data-url="{{ url('/rfms/attachments/'.$attachment->attachment_uniqiueid ?? '') }}">
                                            <i class="sl-icon-trash"></i>
                                    </button></td>
                                </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                @endif
            @endif
        </div>
            <!--pass source-->
            <input type="hidden" name="source" value="{{ request('source') }}">

        </div>

    </div>
</div>
