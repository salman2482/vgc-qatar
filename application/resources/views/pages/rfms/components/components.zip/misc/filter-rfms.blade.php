<!-- right-sidebar -->
<div class="right-sidebar" id="sidepanel-filter-properties">
    <form>
        <div class="slimscrollright">
            <!--title-->
            <div class="rpanel-title">
                <i class="icon-Filter-2"></i>{{ cleanLang(__('lang.filter_properties')) }}
                <span>
                    <i class="ti-close js-toggle-side-panel" data-target="sidepanel-filter-properties"></i>
                </span>
            </div>
            <!--title-->
            <!--body-->
          
            <!--body-->
        </div>
    </form>
</div>
<!--sidebar-->