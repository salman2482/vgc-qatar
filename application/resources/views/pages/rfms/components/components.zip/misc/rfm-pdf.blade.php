<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}" id="meta-csrf" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>{{ config('system.settings_company_name') }}</title>


    <!--
        web preview example
        http://example.com/invoices/29/pdf?view=preview
        {{ BASE_DIR . '/' }}
    -->

    @if (request('view') == 'preview')
        <!--baseurl-->
        <base href="{{ url('/') }}" target="_self">
    @else
        <!--basepath-->
        <base href="" target="_self">
    @endif


    <!--bootstrap-->
    <link href="public/vendor/css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!--selected theme - pdf css-->
    <link href="{{ config('theme.selected_theme_pdf_css') }} " rel="stylesheet">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="public/images/favicon.png">
</head>

<body class="pdf-page">

    <div class="bill-pdf {{ config('css.bill_mode') }} {{ @page['bill_mode'] }}">

        <!--HEADER-->
        <div class="bill-header">
            <!--INVOICE HEADER-->
            <table>
                <tbody>
                    <tr>
                        <td class="x-left">
                            <div class="x-logo">
                                <img src="storage/logos/app/{{ config('system.settings_system_logo_large_name') }}">
                            </div>
                        </td>
                        <td class="x-right">
                            <div class="x-bill-type">
                                <h4><strong>{{ cleanLang(__('RFM Copy')) }}</strong></h4>
                                <h5>#{{ $rfm->ref_num ?? '' }}</h5>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!--ADDRESSES & DATES-->
        <div class="bill-addresses">
            <table>
                <tbody>
                    <tr>
                        <!--company-->
                        <td class="x-left">
                            <div class="x-company-name">
                                <h5 class="p-b-0 m-b-0"><strong>{{ config('system.settings_company_name') }}</strong>
                                </h5>
                            </div>
                            @if (config('system.settings_company_address_line_1'))
                                <div class="x-line">{{ config('system.settings_company_address_line_1') }}
                                </div>
                            @endif
                            @if (config('system.settings_company_state'))
                                <div class="x-line">
                                    {{ config('system.settings_company_state') }}
                                </div>
                            @endif
                            @if (config('system.settings_company_city'))
                                <div class="x-line">
                                    {{ config('system.settings_company_city') }}
                                </div>
                            @endif
                            @if (config('system.settings_company_zipcode'))
                                <div class="x-line">
                                    {{ config('system.settings_company_zipcode') }}
                                </div>
                            @endif
                            @if (config('system.settings_company_country'))
                                <div class="x-line">
                                    {{ config('system.settings_company_country') }}
                                </div>
                            @endif
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="col-12">
            <div class="table-responsive m-t-40 invoice-table-wrapper {{ config('css.bill_mode') }} clear-both">
                <table class="table table-hover invoice-table {{ config('css.bill_mode') }}">
                    <thead>
                        <tr>
                            <!--description-->
                            <th class="text-left x-description bill_col_description">{{ cleanLang(__('RFM Ref #')) }}
                            </th>
                            {{-- trustech code ends here --}}
                            <!--quantity-->
                            <th class="text-left x-quantity bill_col_quantity">{{ cleanLang(__('Department')) }}</th>
                            <th class="text-left x-unit bill_col_unit">{{ cleanLang(__('Subject')) }}</th>
                            <th class="text-left x-unit bill_col_unit">{{ cleanLang(__('Site')) }}</th>
                            <th class="text-left x-quantity bill_col_quantity">{{ cleanLang(__('Material')) }}</th>
                            <th class="text-left x-quantity bill_col_quantity">{{ cleanLang(__('Qty')) }}</th>
                            <th class="text-left x-quantity bill_col_quantity">{{ cleanLang(__('Available Stock')) }}</th>
                            <!--unit price-->
                            <!--rate-->
                            <th class="text-left x-rate bill_col_rate">{{ cleanLang(__('Remarks')) }}</th>
                            <th class="text-left x-rate bill_col_rate">{{ cleanLang(__('Status')) }}</th>

                        </tr>
                    </thead>

                    <tbody id="billing-items-container">
                        <td>{{ $rfm->ref_num }}</td>
                        <td>{{ $rfm->department }}</td>
                        <td>{{ $rfm->subject }}</td>
                        <td>{{ $rfm->site }}</td>
                        <td>{{ $rfm->material_id ?? 'not found' }}</td>
                        <td>{{ $rfm->quantity ?? 'not found' }}</td>
                        <td>{{ $rfm->available_stock ?? 'not found' }}</td>
                        <td>{{ $rfm->remarks ?? 'not found' }}</td>
                        <td>{{ $rfm->status }}</td>
                    </tbody>
                </table>
                @foreach($attachments as $attachment)
                    @if ($attachment->attachment_unique_input === 'rfm_image')
                        <img src="{{ asset('rfms/attachments/download/'.$attachment->attachment_uniqiueid) }}" class="x-logo" width="350" height="300" style="margin-top:30px">
                    @endif
                @endforeach
            </div>
        </div>
    </div>
</body>

</html>
