<div class="invoice-item-actions">

    <!--add blank line-->
    {{-- <button type="button" id="append_row"
        class="btn btn-secondary btn-rounded btn-sm btn-rounded-icon addRow"><i
            class="mdi mdi-plus-circle-outline text-themecontrast"></i>
        <span>{{ cleanLang(__('lang.new_blank_line')) }}</span>
    </button> --}}

    <!--add product item-->
    {{-- <button type="button"
        class="btn btn-secondary btn-rounded btn-sm btn-rounded-icon actions-modal-button js-ajax-ux-request reset-target-modal-form"
        data-toggle="modal" data-target="#itemsModal" data-modal-title="{{ cleanLang(__('Material Item')) }}"
        data-reset-loading-target="true"
        data-url="{{ url('/materials?action=search') }}"
        data-loading-target="materials-table-wrapper"><i class="mdi mdi-cart-outline text-themecontrast"></i>
        <span>{{ cleanLang(__('Material Item')) }}</span>
    </button> --}}


</div>
