<!--modal-->
<div class="modal" role="dialog" aria-labelledby="taxesModal" id="taxesModal" {!! clean(runtimeAllowCloseModalOptions()) !!}>
    <div class="modal-dialog" id="taxesModalContainer">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="taxesModalTitle">Taxes</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body" id="taxesModalBody">
                Foo
            </div>
        </div>
    </div>
</div>