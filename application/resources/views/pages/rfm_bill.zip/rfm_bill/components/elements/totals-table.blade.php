<div class="col-12" id="bill-totals-wrapper">
    <!--total amounts-->
    <div class="pull-right m-t-30 text-right">

       
    </div>
    
</div>